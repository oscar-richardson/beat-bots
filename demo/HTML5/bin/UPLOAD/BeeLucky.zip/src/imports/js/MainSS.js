/*jslint nomen: true, browser: true, plusplus: true, devel: true, vars:true, eqeq: true*/
/*global com, camelot*/

/*Generated from TexturPacker*/

(function (window) {
"use strict";
//set local paths to external files
var camelot = window.com.camelot,
iwg = camelot.iwg,
images = window.com.camelot.core.iwgLoadQ.images,
MainSS= function () {
};

//add and set "next":false to stop on last frame

MainSS.spriteSheet = {
"images": [images.MainSS],
"frames": [

[2, 2, 256, 256]
],
"animations": {

"Button":[0]
}
}
iwg._class("iwg.imports.js.MainSS", MainSS);
}(window));



