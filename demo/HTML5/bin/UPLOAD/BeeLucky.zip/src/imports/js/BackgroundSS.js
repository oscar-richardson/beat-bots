/*jslint nomen: true, browser: true, plusplus: true, devel: true, vars:true, eqeq: true*/
/*global com, camelot*/

/*Generated from TexturPacker*/

(function (window) {
"use strict";
//set local paths to external files
var camelot = window.com.camelot,
iwg = camelot.iwg,
images = window.com.camelot.core.iwgLoadQ.images,
BackgroundSS= function () {
};

//add and set "next":false to stop on last frame

BackgroundSS.spriteSheet = {
"images": [images.BackgroundSS],
"frames": [

[2, 2, 1140, 640]
],
"animations": {

"Background":[0]
}
}
iwg._class("iwg.imports.js.BackgroundSS", BackgroundSS);
}(window));



